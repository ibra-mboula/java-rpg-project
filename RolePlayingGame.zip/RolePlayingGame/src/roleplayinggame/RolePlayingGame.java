package roleplayinggame;

import static java.lang.Thread.sleep;
import be.isib.rpg.Equipement;
import be.isib.ennemi.Monstre;
import be.isib.ennemi.Gobelin;
import be.isib.ennemi.Orc;
import be.isib.ennemi.Demon;
import be.isib.ennemi.Minotaure;
import be.isib.joueur.Heros;
import be.isib.joueur.Guerrier;
import be.isib.joueur.Mage;
import be.isib.joueur.Voleur;
import be.isib.typeArme.armeCaC;
import be.isib.typeArme.armeDistance;
import be.isib.typeArme.armeMagique;
import be.isib.arme.Marteau;
import be.isib.arme.Tromblon;
import be.isib.arme.SceptreDeFeu;


public class RolePlayingGame {

    
    
    private static int round = 1 ; 
    private static int degats;
    private static int degatsPortées;
    private static int nbAttaquePortées;
    private static int degatsRecues;
    private static int nbAttaqueRecues;
    private static int toursAtqSpe  = 1;
    private static int toursAttaque = (int) (Math.random() * 2) ;
    private static int chargeMinautore = 2 ; // 2 a été choisi en fonction de la condition à la ligne 152
    static int nbrAttaqueFeu  = (int) ((Math.random() * 4)) + 1 ;
    private static int toursAtqFeu = 7; //une valeur Aléatoire qui surpérieur aux nbr d'attaque de feu c-a-d > 5
                                         // Elle va servir à exécuter la première attaque de feu, puis elle sera
                                         //redéfinit aléatoirement pour avoir un nbr de brulures aléatoires 
                                         //Necessaire pour effectuer une attaque speciale par un Mage

    
    
    
    
    public static void main(String[] args) {

        Monstre monstre = null ;
        Heros joueur = new Heros();
        Equipement arme = null ;

        System.out.println("\n Debut du RPG BATTLE");
        System.out.println("---------------------\n");
        
        for (int l = 0 ; joueur.getPv() > 0 && round <= 4 ; round++) {// tant que joueur en vie 
            
            nbAttaquePortées = 0 ;nbAttaqueRecues = 0;  degats = 0; degatsPortées = 0;degatsRecues = 0;

            switch (round) {

                case 1: 

                    monstre = new Gobelin();
                    break ;

                case 2: 
                    monstre = new Orc(); 
                    break ;
                case 3: 
                    monstre = new Demon();
                    break ;

                case 4:

                    monstre = new Minotaure();
                    break ;

            }

            
                System.out.println("\n\n\n Le combat contre le " + monstre.getClass().getSimpleName() + " va commencer");
                System.out.println("---------------------------------------------\n");
        
            for (int b; joueur.getPv() > 0 && monstre.getPv() > 0; toursAttaque++) {
                        
                if (toursAttaque % 2 != 0) {
// Attaque spéciale et Attaque simple du Heros

                    if (joueur instanceof Guerrier && arme instanceof Marteau   && toursAtqSpe % 5 == 0) { // la valeur 5 utilisé pour une atq
                                                                                                         // tous les 4 tours

                    int nbrAtqMarteau = (int) ((Math.random() * 3)) + 1 ; // gestion du nbr d'atq au marteau, quand le Minau est étourdi, il attaque 1 ou 2 ou 3 fois
                                                                          // +1 en cas de 0 généré 
                    ((Marteau) arme).attSpeciale(); // elle sert juste a afficher l'attaque speciale marteau
                    

                    System.out.println("\nLe "+monstre.getClass().getSimpleName() + " est étourdi !!\n");

                    for (int a = 0; (a < nbrAtqMarteau) && toursAtqSpe % 5 == 0; a++) { // pour gerer les attaques en elles memes 
                                                                                        // si nbr tours = 3 il attaques 3 fois d'affilé car le Minau est étourdi

                        attaqueHeros(monstre, joueur,arme);

                    }
                 

                } else if (joueur instanceof Voleur && arme instanceof Tromblon &&  toursAtqSpe % 5 == 0) {
                   
                    int randAtqTromblon = (int) ((Math.random() * 2)) + 2; // 2 est la pour avoir un bon nbr d'attaque correcte
                    ((Tromblon) arme).attSpeciale() ; 

                    for (int i = 0; i < randAtqTromblon && toursAtqSpe % 5 == 0; i++) {

                        System.out.println("\nTir  " + (i + 1));
                        attaqueHeros(monstre, joueur,arme);

                    }
                   

                } else if (arme instanceof SceptreDeFeu && joueur instanceof Mage && toursAtqSpe % 5 == 0) {
                    
                    ((SceptreDeFeu) arme).attSpeciale();
                    
                    System.out.println( nbrAttaqueFeu);
                    System.out.println("Brulure 1 !");
                    System.out.println("PV du Minautore = " + monstre.getPv() + " - 2 = " + (monstre.getPv() - 2));

                    attaqueSceptreFeu(monstre, joueur,arme);
                    toursAtqFeu = 0; // On réinitialise pour ne pas avoir le meme nbr de brulure à chq Attaque de feu

                } else if (arme instanceof armeCaC || arme instanceof armeDistance || arme instanceof armeMagique) {

                    attaqueHeros(monstre, joueur,arme); // attaque simple d'un Heros

                } else {
                    attaqueHeros(monstre, joueur,arme);// Attaque d'un heros non spécialisé si non boucle infini
                } 
                   
// Attaque spéciale et simple des Monstres 
// Gestion des degats recus par les brulures

                    toursAtqFeu++;
                   if (!(monstre instanceof Minotaure)) { 
                        attaqueMonstre(monstre, joueur); //Attaque simple d'un monstre
                    }
       
                    if (arme instanceof SceptreDeFeu && toursAtqFeu < nbrAttaqueFeu) { //pour la comparaison < c'est tjr vrai (ref ligne 33)
                        System.out.println("Brulure " + (toursAtqFeu + 1) );
                        System.out.println("PV du monstre : " + monstre.getPv() + " - 2 : " + (monstre.getPv() - 2));
                        monstre.setPv(monstre.getPv() - 2);// Chaques brulure inflige une reduction de 2 pv au monstre
                        nbrAttaqueFeu = (int) ((Math.random() * 4)) + 1;// comme dit à la ligne 33 on réinitialise pour ne pas avoir
                                                                        // le meme nbr de brulure
                    }
// Gestion de la charge du Minautore                    
                    if (monstre instanceof Minotaure ) {

                        chargeMinautore++; // cette valeur sera réinitialisé à chaques charge elle est nécessaire pour faire fonctionner correctement 
                                           // les conditions ci dessous 
                        if (chargeMinautore != 1) {// elle sert à temporisé la charge du Minautore pour permettre au heros
                                                   // de faire des attaques succéssivent avant la charge

                            if (monstre.getAttaqueMonstre() != 8) { // ici on check si la valeur de son attaque est !=8 
                                                                    //si c'est le cas c'est une attaque simple du Minau
                                                                    // verificeation nécessaire si non il fait une charge a tous les tours

                                charge(monstre, joueur);
                            } else {
                                attaqueMonstre(monstre, joueur); // ici c'est une attq classique du minautore
                            }
                            monstre.setAttaqueMonstre(8);// reinitialisation de l'attaque du minautore avec ou sans la charge
                                                         // pour corriger un bug lors du délais de récupération de la charge 
                        }

                        if (toursAtqSpe % 5 == 0 ) {

                            ((Minotaure) monstre).attSpeciale();

                            chargeMinautore = 0; // necéssaire pour 2 atq succéssivent du heros

                        }
                    }
                }   
                
                toursAtqSpe++ ;

            }

// Recapitulatif des combats et remplissage des valeurs dans le tableau de fin 

            Heros FightRecap = joueur ;// Cette variable va servir a garder une copie des stats du joueur 
                                       // si non elles sont réinitialisé

           
            String recapitulatif[][] = FightRecap.getRecapCombats();
         
            recapitulatif[round - 1][0] = String.valueOf(monstre.getClass().getSimpleName());

            recapitulatif[round - 1][1] = String.valueOf("     " + nbAttaquePortées);
            recapitulatif[round - 1][2] = String.valueOf("     " + degatsPortées);
            recapitulatif[round - 1][3] = String.valueOf("     " + nbAttaqueRecues);
            recapitulatif[round - 1][4] = String.valueOf("     " + degatsRecues);

       
            for (int i = 0 ; i < 4 ; i++) { // pour mettre un espace vide au cas ou une valeur null est présente dans le tableau

                for (int j = 0; j < 6 && recapitulatif[i][j] == null; j++) {

                    recapitulatif[i][j] = String.valueOf("  ");

                }
            }
            
            if (recapitulatif[round - 1][5] == "  ") { // cas ou aucun item n'est ramassé
                recapitulatif[round - 1][5] = "** Aucun**";

            }

//Drop du joueur 
            if (joueur.getPv() == 0) {
                
                    System.out.println("\nFin de la partie vous avez perdu :(");
                    System.out.println("--------------------------------------");
                    
            } else if (joueur.getPv() > 0 ){

                    if (round < 4) {
                        
                        arme = joueur.drop(monstre);
                        

// Specialisation du joueur
                        
                        if (arme instanceof armeCaC) {

                            joueur = new Guerrier();
                        }                  
                        else if (arme instanceof armeDistance) {

                            joueur = new Voleur();

                        }                   
                        else if (arme instanceof armeMagique) {

                            joueur = new Mage();

                        }
                    
                        recapitulatif[round - 1][5] = arme.getNom();
 
                        joueur.setPv(FightRecap.getPv());;//conservation des pv apres combat
                        
                        System.out.println("\n|++++++++++++++++++++++++++++");
                        System.out.println("| Le "+monstre.getClass().getSimpleName()+" est K.O");
                        System.out.println("| Pv du "+joueur.getClass().getSimpleName()+" = "+ joueur.getPv());
                        System.out.println("| Vous avez drop une " + arme.getNom());
                        System.out.println("|++++++++++++++++++++++++++++");
                        
                    }

//Réinitialisation des Pv du Heros après le combat contre le Demon

                switch(round){

                    case (3) :
                        
                        joueur.setPv(35);

                        System.out.println("\nReinitialisation des Pv du "+ joueur.getClass().getSimpleName() +", pv = " + joueur.getPv());
                        break ;
                    
                    case (4) :
                    
                        System.out.println("\n\nFin de la partie vous avez gagné.");
                    }
            }

            joueur.setRecapCombats(recapitulatif);
        }

        System.out.println("\n\n" + joueur.tableauFin());

    }
    
// methode statique pour gerer les attaques des monstres et heros
     private static void attaqueHeros(Monstre monstre, Heros joueur,Equipement arme) {

        System.out.print("Le " + joueur.getClass().getSimpleName() + " attaque ");
        try {
            sleep(200);
        } catch (InterruptedException execption) {
        }

        degats = Math.max(joueur.attaqueCaC(monstre,arme), Math.max(joueur.attaqueMagique(monstre,arme), joueur.attaqueADistance(monstre,arme)));
        degatsPortées = degatsPortées + degats;
        nbAttaquePortées++;

        monstre.setPv(monstre.getPv() - degats);

        System.out.printf("\t\t Dégâts infligés = %4d", degats);

        System.out.printf("\tPV " + monstre.getClass().getSimpleName() + " =  %4d\n", monstre.getPv());

    }

        public static void attaqueSceptreFeu(Monstre monstre, Heros joueur,Equipement arme) {

        System.out.print("Le " + joueur.getClass().getSimpleName() + " attaque ");
        try {
            sleep(200);
        } catch (InterruptedException execption) {
        }
    
        degats = joueur.attaqueMagique(monstre,arme);
        degatsPortées = degatsPortées + degats;
        nbAttaquePortées++; 

        monstre.setPv(monstre.getPv() - (degats + 2));


        System.out.printf("\t\t Dégâts infligés = %4d", degats);
       
        System.out.printf("\tPV " + monstre.getClass().getSimpleName() + " =  %4d\n", monstre.getPv());

    }
    
    private static void attaqueMonstre(Monstre monstre, Heros joueur) {

        System.out.print("Le " + monstre.getClass().getSimpleName() + " attaque ");

        try {
            sleep(200);
        } catch (InterruptedException execption) {
        }

        degats = monstre.attaqueMonstre(joueur);
        degatsRecues = degatsRecues + degats;
        nbAttaqueRecues++;
        
        joueur.setPv(joueur.getPv() - degats);

        System.out.printf("\t\t Dégâts reçus = %4d", degats);
        System.out.printf("\tPV " + joueur.getClass().getSimpleName() + " =  %4d\n", joueur.getPv());
    }

    private static void charge(Monstre monstre, Heros joueur) {

        System.out.print("Le " + monstre.getClass().getSimpleName() + " CHARGE ! ");
        try {
            sleep(200);
        } catch (InterruptedException execption) {
        }

        degats = monstre.attaqueMonstre(joueur);
        degatsRecues = degatsRecues + degats;
        nbAttaqueRecues++;

        joueur.setPv(joueur.getPv() - degats);

        System.out.printf("\t\t Dégâts reçus = %4d", degats);
        System.out.printf("\tPV " + joueur.getClass().getSimpleName() + " =  %4d\n", joueur.getPv());
    }

}
