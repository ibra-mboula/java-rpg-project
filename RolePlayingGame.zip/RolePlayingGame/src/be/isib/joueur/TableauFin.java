
package be.isib.joueur;

public class TableauFin extends Heros {
    
     @Override
     public String tableauFin() {

        String tableauFin = "\nTableau récapitulatif \n";
        tableauFin +="------------------------\n" ;

        tableauFin += "\n|Monstre combattu     \tAttaques portées     \tDégâts infligés     \t  Attaques reçues    \tDégâts reçus     Item ramassés\n";

        tableauFin += " -----------------|----------------------|----------------------|----------------------|-----------------|--------------------|\n";
        tableauFin += "                  |                      |                      |                      |                 |                    |\n";

        for (int i = 0; i < RecapCombats.length; i++) {

            for (int j = 0; j < RecapCombats[i].length; j++) {

                tableauFin += RecapCombats[i][j] + "\t\t\t";
            }

            tableauFin += "\n";

        }
        return tableauFin ;
    
}}
