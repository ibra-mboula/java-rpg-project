package be.isib.joueur;

import be.isib.arme.Arbalette;
import be.isib.arme.Arc;
import be.isib.arme.Baton;
import be.isib.arme.Epee;
import be.isib.arme.Glaive;
import be.isib.arme.Marteau;
import be.isib.arme.Sceptre;
import be.isib.arme.SceptreDeFeu;
import be.isib.arme.Tromblon;
import be.isib.rpg.Personnage;
import be.isib.ennemi.Monstre;
import be.isib.rpg.Equipement;

public class Heros extends Personnage {

    private int force;
    private int precision;
    private int intelligence;
    private Equipement[] inventaire;
    protected String RecapCombats[][];

    public Heros() {

        setPv(30);
        setDefense(5);
        this.force = 1;
        this.precision = 1;
        this.intelligence = 1;
        this.inventaire = new Equipement[3];
        this.RecapCombats = new String[4][6];
    }

    public int bestArme(int degatArme, Equipement arme) { // methode pour selectionner la meilleur arme dans 
        // le tableau Equipement, elle prendra l'arme de la
        // case suivante.

        if (this.getInventaire()[0] != null) {

            if (this.getInventaire()[1] == null && getInventaire()[2] == null && getInventaire()[3] == null) {
                arme = this.getInventaire()[0];
            }
            if (this.getInventaire()[1] != null && getInventaire()[2] == null && getInventaire()[3] == null) {
                arme = this.getInventaire()[1];
            }
            if (this.getInventaire()[1] != null && getInventaire()[2] != null && getInventaire()[3] == null) {
                arme = this.getInventaire()[2];
            } else {
                arme = this.getInventaire()[3];
            }

           
        }
        return degatArme;

    }

    public Equipement drop(Monstre monstre) {

        if (inventaire[0] == null) {

            inventaire[0] = monstre.getArme();
            return inventaire[0];

        } else if (inventaire[0] != null && inventaire[1] == null) {

            inventaire[1] = monstre.getArme();
            return inventaire[1];

        } else {
            return inventaire[2] = monstre.getArme();
        }

    }

    public int attaqueCaC(Monstre monstre , Equipement arme) {

       

        int degatArme = 0;
        int degatCaC;

        int randAttaque = (int) (Math.random() * 5);
        int attaque = this.force + randAttaque - 2;

        int randDefense = (int) (Math.random() * 5);
        int defenseMonstre = monstre.getDefense() + randDefense - 2;

        if (this.getInventaire()[0] != null) {

            if (this.getInventaire()[1] == null && getInventaire()[2] == null ) {
                arme = this.getInventaire()[0];
            }
            if (this.getInventaire()[1] != null && getInventaire()[2] == null ) {
                arme = this.getInventaire()[1];
            }
            if (this.getInventaire()[1] != null && getInventaire()[2] != null ) {
                arme = this.getInventaire()[2];
            } else {
                arme = this.getInventaire()[3];
            }
            
        }

        if (arme instanceof Epee) {

            degatArme = 2 ;
            

        }
        if (arme instanceof Glaive) {

            degatArme = 4 ;

        }
        if (arme instanceof Marteau) {

            degatArme = 5 ;

        }
        
        /*System.out.println(" degattttttt arme === "+degatArme); VERIFICATION BONUS
        System.out.println(" attaque === "+attaque);*/

        degatCaC = (attaque + degatArme) - defenseMonstre;
        
        

        if (degatCaC < 0) {
            return 0;
        } else {
            return degatCaC;
        }

    }

    public int attaqueADistance(Monstre monstre , Equipement arme) {

      

        int degatArme = 0;
        int degatDistance;

        int randAttaque = (int) (Math.random() * 5);
        int attaque = this.precision + randAttaque - 2;

        int randDefense = (int) (Math.random() * 5);
        int defenseMonstre = monstre.getDefense() + randDefense - 2;

        if (this.getInventaire()[0] != null) {

            if (this.getInventaire()[1] == null && getInventaire()[2] == null ) {
                arme = this.getInventaire()[0];
            }
            if (this.getInventaire()[1] != null && getInventaire()[2] == null ) {
                arme = this.getInventaire()[1];
            }
            if (this.getInventaire()[1] != null && getInventaire()[2] != null ) {
                arme = this.getInventaire()[2];
            } else {
                arme = this.getInventaire()[3];
            }

       
        }
        
        if (arme instanceof Arc) {

            degatArme = 2 ;
           
        }
        if (arme instanceof Arbalette) {

            degatArme = 4 ;

        }
        if (arme instanceof Tromblon) {

            degatArme = 5 ;

        }
        
       /*
        System.out.println(" degattttttt arme === "+degatArme); POUR VERIFIER SI LE BONUS EST APPLIQUE
        System.out.println(" attaque === "+attaque);*/


        degatDistance = (attaque + degatArme) - defenseMonstre;

        if (degatDistance < 0) {
            return 0;
        } else {
            return degatDistance;
        }
    }

    public int attaqueMagique(Monstre monstre , Equipement arme) {

       

        int degatArme = 0;
        int degatMagique;

        int randAttaque = (int) (Math.random() * 5);
        int attaque = this.intelligence + randAttaque - 2;

        int randDefense = (int) (Math.random() * 5);
        int defenseMonstre = monstre.getDefense() + randDefense - 2;

        if (this.getInventaire()[0] != null) {

            if (this.getInventaire()[1] == null && getInventaire()[2] == null ) {
                arme = this.getInventaire()[0];
            }
            if (this.getInventaire()[1] != null && getInventaire()[2] == null ) {
                arme = this.getInventaire()[1];
            }
            if (this.getInventaire()[1] != null && getInventaire()[2] != null ) {
                arme = this.getInventaire()[2];
            } else {
                arme = this.getInventaire()[3];
            }

        }
        
        if (arme instanceof Baton) {

            degatArme = 2 ;
           
        }
        if (arme instanceof Sceptre) {

            degatArme = 4 ;

        }
        if (arme instanceof SceptreDeFeu) {

            degatArme = 5 ;

        }
        
        
        /*System.out.println(" degattttttt arme === "+degatArme);
        System.out.println(" attaque === "+attaque);*/

        degatMagique = (attaque + degatArme) - defenseMonstre;

        if (degatMagique < 0) {
            return 0;
        } else {
            return degatMagique;
        }

    }

    public int getForce() {
        return this.force;

    }

    public void setForce(int force) {

        this.force = force;
    }

    public int getPrecision() {
        return this.precision;

    }

    public void setPrecision(int precision) {
        this.precision = precision;
    }

    public int getIntelligence() {
        return this.intelligence;

    }

    public void setIntelligence(int intelligence) {

        this.intelligence = intelligence;
    }

    public String[][] getRecapCombats() {

        return this.RecapCombats;
    }

    public void setRecapCombats(String[][] recapCombats) {

        this.RecapCombats = recapCombats;
    }

    public Equipement[] getInventaire() {
        return this.inventaire;
    }

    public void setInventaire(Equipement[] inventaire) {
        this.inventaire = inventaire;
    }

    public String tableauFin() {
        
        

        String tableauFin = "\nTableau récapitulatif \n";
        tableauFin +="------------------------\n" ;

        tableauFin += "\n|Monstre combattu     \tAttaques portées     \tDégâts infligés     \t  Attaques reçues    \tDégâts reçus     Item ramassés\n";

        tableauFin += " -----------------|----------------------|----------------------|----------------------|-----------------|--------------------|\n";
        tableauFin += "                  |                      |                      |                      |                 |                    |\n";

        for (int i = 0; i < RecapCombats.length; i++) {

            for (int j = 0; j < RecapCombats[i].length; j++) {

                tableauFin += RecapCombats[i][j] + "\t\t\t";
            }

            tableauFin += "\n";

        }
        return tableauFin;
    }

}
