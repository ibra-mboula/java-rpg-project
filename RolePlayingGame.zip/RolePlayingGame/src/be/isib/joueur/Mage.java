package be.isib.joueur;

public class Mage extends Heros{

        public Mage() {
            
        setIntelligence(5);
        setPrecision(4);
        setForce(2);
    }
}

