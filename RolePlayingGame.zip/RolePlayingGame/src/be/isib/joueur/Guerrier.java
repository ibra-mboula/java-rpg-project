package be.isib.joueur;

public class Guerrier extends Heros {

    public Guerrier() {
        
        setIntelligence(2);
        setPrecision(4);
        setForce(5);
    }
}
