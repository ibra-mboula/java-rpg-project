package be.isib.joueur;

public class Voleur extends Heros {

    public Voleur() {

        setIntelligence(2);
        setPrecision(5);
        setForce(4);
    }
}
