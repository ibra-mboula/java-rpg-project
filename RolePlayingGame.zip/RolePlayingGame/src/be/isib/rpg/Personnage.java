package be.isib.rpg;

public abstract class Personnage {

    protected int pv ; // santé d'un personnage
    protected int defense ; 

    public void setPv(int pv) { 
        this.pv =  pv ; 
        
        if (pv <= 0) {// cette condition est nécessaire pour ne pas avoir des pv 
                       // négatifs et une boucle sans fin
            this.pv = 0 ;
        }
    }

    public int getPv() {
        return pv ;
    }

    public void setDefense(int defense) { 
        this.defense = defense ;
    }
  
    public int getDefense() {
        return defense ;
    }

}
