
package be.isib.rpg;

public abstract class Equipement { 

    protected String nom = null ; 
    protected int niveau = 0 ;
    public int bonusArme ;
    
    public void setNom (String nom) { // va servir à modifier le nom de l'arme
        this.nom = nom ;
    }
    
    public String getNom() { // pour recuperer le nom de l'arme en string 
        return this.nom ;
    }

    public void setNiveau (int niveau) {
        this.niveau = niveau ;
    }

    public int getNiveau() {
        return this.niveau ;
    }

   
}
