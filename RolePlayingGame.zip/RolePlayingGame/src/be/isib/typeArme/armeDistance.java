
package be.isib.typeArme;

import be.isib.rpg.Equipement;

public class armeDistance extends Equipement {// arc ,arbalète , tromblon , elle va juste pointer vers
//les équipements dont elle sera la classe mère

    }
