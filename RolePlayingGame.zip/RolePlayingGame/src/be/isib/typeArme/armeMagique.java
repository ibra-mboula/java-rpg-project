
package be.isib.typeArme;

import be.isib.rpg.Equipement;

public class armeMagique extends Equipement {
// Baton , sceptre , sceptre de feu , elle va juste pointer vers
//les équipements dont elle sera la classe mère
   
    }


