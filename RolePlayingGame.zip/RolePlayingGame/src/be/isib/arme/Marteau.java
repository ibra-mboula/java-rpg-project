package be.isib.arme;

import be.isib.typeArme.armeCaC;

public class Marteau extends armeCaC implements ArmeSpeciale {

    public Marteau() {
        setNom(" Marteau");
        setNiveau ( 3 );
        

    }

    @Override
    public void attSpeciale() {
        System.out.print("\nATTAQUE SPECIALE MARTEAU !! ");

    }

}
