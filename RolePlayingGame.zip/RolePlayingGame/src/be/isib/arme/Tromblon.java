
package be.isib.arme;

import be.isib.typeArme.armeDistance;

public class Tromblon extends armeDistance implements ArmeSpeciale {
    
    public Tromblon(){
    setNom("Tromblon") ;
    setNiveau (3) ;
    
    }

    @Override
    public void attSpeciale() {
        
        System.out.print("\nATTAQUE SPECIAL, TIR A LA CHAINE "); 

    }
    
}
