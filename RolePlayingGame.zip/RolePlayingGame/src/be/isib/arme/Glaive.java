package be.isib.arme;

import be.isib.typeArme.armeCaC;

public class Glaive extends armeCaC {

    public Glaive() {

        setNom( "glaive");
        setNiveau (2);
       

    }
}
