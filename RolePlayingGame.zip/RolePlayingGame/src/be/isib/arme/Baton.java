package be.isib.arme;

import be.isib.typeArme.armeMagique;

public class Baton extends armeMagique {

    public Baton() {

        setNom ("baton");
        setNiveau (1);
      
    }
    
}
