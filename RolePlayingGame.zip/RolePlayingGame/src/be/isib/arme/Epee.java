
package be.isib.arme;

import be.isib.typeArme.armeCaC;

public class Epee extends armeCaC {
    
   public Epee (){
  
  setNom ("Epee");     
  setNiveau(1);

   }
   
   
}