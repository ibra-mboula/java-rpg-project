package be.isib.arme;

import be.isib.typeArme.armeDistance;

public class Arc extends armeDistance {

    public Arc() {
        
        setNom ("Arc");
        setNiveau (1);
   
    }
    

}
