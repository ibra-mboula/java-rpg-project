package be.isib.arme;

import be.isib.typeArme.armeMagique;

public class Sceptre extends armeMagique {

    public Sceptre() {

        this.nom = "Sceptre" ;
        this.niveau = 2 ;
        this.bonusArme = 4 ;

    }
}
