
package be.isib.arme;

public interface ArmeSpeciale {

    public abstract void attSpeciale();

}
