package be.isib.arme;

import be.isib.typeArme.armeMagique;

public class SceptreDeFeu extends armeMagique implements ArmeSpeciale {

    public SceptreDeFeu() {
        setNom ( "SceptreDeFeu");
        setNiveau (3);
        
    }

    @Override
    public void attSpeciale() {

        System.out.print("\nATTAQUE SPECIALE DE FEU,Nombre de tours de brulures  =  ");

    }
}
