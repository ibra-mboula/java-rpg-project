package be.isib.arme;

import be.isib.typeArme.armeDistance;

public class Arbalette extends armeDistance {

    public Arbalette() {
        setNom("arbalette");
        setNiveau ( 1) ;
        
    }
}
