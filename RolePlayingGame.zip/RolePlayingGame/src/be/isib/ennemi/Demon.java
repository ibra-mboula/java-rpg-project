
package be.isib.ennemi;

import be.isib.arme.Marteau;
import be.isib.arme.SceptreDeFeu;
import be.isib.arme.Tromblon;

public class Demon extends Monstre {

    public Demon() {
        
        setPv(20) ;
        setDefense(5);
        setAttaqueMonstre(5);

        int randArme3 = (int) (Math.random() * 3);

        switch (randArme3) {
            case 0:
                this.arme = new Marteau ();
                break;
            case 1:
                 this.arme = new SceptreDeFeu();
                break;
                
            case 2:
               this.arme = new Tromblon();
                break;
        }
    }

}
