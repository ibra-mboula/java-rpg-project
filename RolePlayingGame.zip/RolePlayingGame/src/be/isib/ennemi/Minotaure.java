
package be.isib.ennemi;

public class Minotaure extends Monstre {

    public Minotaure(){
        
        setPv(35) ;
        setDefense(8);
        setAttaqueMonstre(8);
          
    }

    public void attSpeciale() {
       
        System.out.println("\nLE MINAUTORE PREPARE UNE CHARGE\n ");
        int attaque = (int) (Math.random() * 3);

                            switch (attaque) {
                                case 0:
                                   setAttaqueMonstre(11);
                                    break;
                                case 1:
                                   setAttaqueMonstre(10);
                                    break;
                                case 2:
                                  setAttaqueMonstre(9);
                                    break;

                            }


    }
    
}
