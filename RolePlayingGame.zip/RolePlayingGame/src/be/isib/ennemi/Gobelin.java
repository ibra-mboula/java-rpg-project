
package be.isib.ennemi;

import be.isib.arme.Arc;
import be.isib.arme.Baton;
import be.isib.arme.Epee;


public class Gobelin extends Monstre {

    public Gobelin() {
        
        setPv(5) ;  
        setDefense(0);
        setAttaqueMonstre(2);
        
        
        int randArme1 = (int) (Math.random() * 3); // le gobelin ne genere qu'une 
                                                 //arme de niv 1 sur les 3 aléatoires

        switch (randArme1) {
 
            case 0:
                this.arme = new Epee();
                break ;
            case 1:
                this.arme  = new Arc();
                break ;
            case 2:
                this.arme= new Baton();
                break ;
        }

    }

}
