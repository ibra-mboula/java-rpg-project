
package be.isib.ennemi;

import be.isib.rpg.Personnage;
import be.isib.joueur.Heros;
import be.isib.rpg.Equipement;


public abstract class Monstre extends Personnage {  
 

    private int attaqueMonstre ; 
    public Equipement arme ; 
    
    
    
    
    
    public int attaqueMonstre(Heros heros) {// Lorsque le monstre attaque le heros

     
        int randAttaque = (int) (Math.random() * 5); // pour avoir un nombre aléatoire entre 0 et 4
        int attaqueMonstre = this.attaqueMonstre + randAttaque - 2 ;// Le -2 est néccessaire pour avoir un range de +-2
        
        int randDefense = (int) (Math.random() * 5); 
        int defenseHeros = heros.getDefense() + randDefense - 2 ;

        int degats = attaqueMonstre - defenseHeros ;

        if (degats < 0) { // si la defense du heros > attaqueMonstre, aucun degat recu
            return 0 ;
        }else {
              return degats;
        }
      
    }

      public void setAttaqueMonstre(int attaque) {
        this.attaqueMonstre = attaque ;
    }
      
    public int getAttaqueMonstre() {
        return this.attaqueMonstre ;
    }
    
      public void setArme(Equipement arme) {
        this.arme = arme ;
    }
 
    public Equipement getArme() {
        return this.arme ;
    }


}
