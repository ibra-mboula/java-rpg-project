
package be.isib.ennemi;

import be.isib.arme.Arbalette;
import be.isib.arme.Glaive;
import be.isib.arme.Sceptre;

public class Orc extends Monstre {

    public Orc() {
    
        setPv(10) ;
        setDefense(2);
        setAttaqueMonstre(3);
        
        int randArme2 = (int) (Math.random() * 3);

        switch (randArme2) {
            case 0:
                this.arme = new Glaive() ;
                break;
            case 1:
                this.arme = new Sceptre();
                break;
            case 2:
                this.arme = new Arbalette();
                break;
        }
    }

}
